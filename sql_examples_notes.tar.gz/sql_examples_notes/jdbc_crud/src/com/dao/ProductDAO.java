package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pojo.Product;

public class ProductDAO {

	public Connection getDBConnection() {

		Connection conn = null;

		try {

			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/simplilearn", "root", "Simplilearn"); // 2.
																													// get
																													// db
																													// connection

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 1. register driver class
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;

	}

	public List getAllProducts() {

		List<Product> list = new ArrayList<Product>();

		Connection conn = getDBConnection();

		String query = "select * from product";

		try {
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);

			ResultSet rs = stmt.executeQuery(query);
			/*
			
			rs.next();
			rs.next();
			rs.next();
			
			
			
			while(rs.previous()) {
				
				
				
			Product   p = new Product();
				
			p.setPid(rs.getInt(1));
			p.setPname(rs.getString(2));
			p.setPrice(rs.getDouble("price"));
			
			list.add(p);
			
				
				
				
			}*/
			
			
			

			/*while (rs.next()) {

				int pid  = rs.getInt(1);
				String pname = rs.getString(2);
				double  price  = rs.getDouble("price");
				
				//System.out.println(rs.getInt(1) + " " + rs.getString("pname") + " " + rs.getDouble("price"));

				Product product = new Product();
				
				product.setPid(pid);
				
				product.setPname(pname);
				
				product.setPrice(price);

				list.add(product);

			}*/

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}

}
