package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DBUtil;
import com.dao.ProductDAO;
import com.pojo.Product;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ProductServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter  out  = response.getWriter();
		
		response.setContentType("text/html");
		
		ProductDAO dao  = new ProductDAO();
		
		
		String  pid = request.getParameter("pid");
		/*
		String pname = request.getParameter("pname");
		
		String  price  = request.getParameter("price");
		
		Product product  = new Product();
		
			product.setPid(Integer.parseInt(pid));
			product.setPname(pname);
			product.setPrice(Double.parseDouble(price));*/
			
			//int count =		dao.insertProduct(product);
			
			//out.print(count + " succesfully added..");
		
			
			
		
			//int count =		dao.updateProduct(product);
			
			//out.print(count +"successfully updated..");
			
			
	int count =		dao.deleteProduct(Integer.parseInt(pid));
			
				out.print(count + " deleted successfully..");
			
			//	DBUtil.closeDBConnection();
					
		
		
		
		// select all products
		
      /*  List<Product> list =   dao.getAllProducts();
        
      
        	for (Product product : list) {
        		
        		
        		out.print(product.getPid() +"  "+product.getPname() +" " +product.getPrice());
        		out.print("<br/>");
				
			}*/
        	
        	
        
          
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
