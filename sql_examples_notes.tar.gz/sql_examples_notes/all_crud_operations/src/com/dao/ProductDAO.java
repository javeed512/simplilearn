package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pojo.Product;

public class ProductDAO {

	public int insertProduct(Product p) {

		int count = 0;

		Connection conn = DBUtil.getDBConnection();

		String insert = "insert into product  values(?,?,?)"; // ? positional params

		try {

			PreparedStatement pstmt = conn.prepareStatement(insert);

			pstmt.setInt(1, p.getPid());
			pstmt.setString(2, p.getPname());
			pstmt.setDouble(3, p.getPrice());

			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;

	}

	public int updateProduct(Product p) {

		int count = 0;

		Connection conn = DBUtil.getDBConnection();

		String update = "update product  set  pname  = ? , price = ? where  pid  = ?"; // ? positional params

		try {

			PreparedStatement pstmt = conn.prepareStatement(update);

			pstmt.setString(1, p.getPname());
			pstmt.setDouble(2, p.getPrice());
			pstmt.setInt(3, p.getPid());

			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;

	}

	
	
	
	
	
	
	public int  deleteProduct(int pid) {
		
		
		int count = 0;

		Connection conn = DBUtil.getDBConnection();

		String  delete   = "delete from product where pid  = ?";// ? positional params

		try {

			PreparedStatement pstmt = conn.prepareStatement(delete);
			
			pstmt.setInt(1, pid);


			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	public List getAllProducts() {

		List<Product> list = new ArrayList<Product>();

		Connection conn = DBUtil.getDBConnection();

		String query = "select * from product";

		try {
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);

			ResultSet rs = stmt.executeQuery(query);
			/*
			 * 
			 * rs.next(); rs.next(); rs.next();
			 * 
			 * 
			 * 
			 * while(rs.previous()) {
			 * 
			 * 
			 * 
			 * Product p = new Product();
			 * 
			 * p.setPid(rs.getInt(1)); p.setPname(rs.getString(2));
			 * p.setPrice(rs.getDouble("price"));
			 * 
			 * list.add(p);
			 * 
			 * 
			 * 
			 * 
			 * }
			 */

			while (rs.next()) {

				int pid = rs.getInt(1);
				String pname = rs.getString(2);
				double price = rs.getDouble("price");

				// System.out.println(rs.getInt(1) + " " + rs.getString("pname") + " " +
				// rs.getDouble("price"));

				Product product = new Product();

				product.setPid(pid);

				product.setPname(pname);

				product.setPrice(price);

				list.add(product);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;

	}

}
