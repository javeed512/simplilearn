package com.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	
	
	static Connection conn = null;
	

	public static Connection getDBConnection() {

		

		try {

			// InputStream in =
			// getServletContext().getResourceAsStream("/WEB-INF/application.properties");
			// use in servlet pgm

			FileInputStream fis = new FileInputStream("/home/javeedmohammedj/eclipse-workspace/all_crud_operations/WebContent/application.properties");

			Properties prop = new Properties();

			prop.load(fis);

			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String username = prop.getProperty("username");
			String password = prop.getProperty("password");

			Class.forName(driver);

			conn = DriverManager.getConnection(url,username,password); // 2.
													// get
													// db
													// connection

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // 1. register driver class
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;

	}
	
	
	public  static  void  closeDBConnection() {
		
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	

}
