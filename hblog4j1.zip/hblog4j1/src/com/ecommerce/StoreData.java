package com.ecommerce;
import org.hibernate.*;
import org.hibernate.cfg.*;

public class StoreData {
public static void main(String[] args) {
	
	Configuration cfg=new Configuration();
	cfg.configure("hibernate.cfg.xml");
	
	SessionFactory factory=cfg.buildSessionFactory();
	Session session=factory.openSession();
	System.out.println("Session Opened...");
	System.out.println("Logged by xml ...");
	System.out.println("session closed");
	
		session.close();
	System.out.println("record successfully persisted");
	
}
}
